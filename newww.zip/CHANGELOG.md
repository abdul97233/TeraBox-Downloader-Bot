# Changelog

All notable changes to the TeraBox Downloader Bot.

---

## v3.6 — Broadcast Fixes (2026-09-21)

### Broadcast Overhaul
- **Removed duplicate legacy `/broadcast` handler** in `commands/ux.py` — both handlers were firing, causing double sends (one with forward tag, one preview)
- **Removed "Forwarded from" tag** — reply+`/broadcast` now uses `drop_author=True` (sends as copy)
- **Fixed caption flow** — media broadcast now correctly switches to `wait_caption` state (caption input was silently ignored before)
- **Sticker detection fixed** — `m.sticker` checked before `m.document`; sticker mode requires a sticker, media mode rejects stickers
- **Async-safe user collection** — `_collect_ids` awaits coroutines directly instead of `run_until_complete` (crashed inside running loop)
- **Consolidated send logic** — single `_deliver()` helper (text/media/sticker/forward) used for normal + FloodWait-retry paths
- **Commands no longer swallowed** — `/command` messages ignored by broadcast content handler while waiting for input
- **Progress updates every chunk** — removed broken modulo check that rarely triggered

---

## v3.5 — Config Backup/Restore (2026-09-21)

### Config Backup
- **`/config_backup`** — sends config.py file to owner via bot
- **`/set_config`** — restore config.py by replying to a file
- Syntax check before replacing — invalid config rejected
- Auto-backup old config to `config.py.bak`
- Audit log for both operations

---

## v3.4 — API Management + Watermark Skip (2026-09-21)

### API Endpoint Management from Bot
- **`/setapi`** — shows current endpoints with health status
- **`/setapi add <name> <url> [token]`** — add new API endpoint
- **`/setapi remove <name>`** — remove endpoint
- **`/setapi edit <name> <url> [token]`** — update endpoint URL/token
- **`/setapi list`** — show all endpoints with stats
- **Persisted to Redis** — endpoints survive restarts
- **Legacy compatibility** — `/setapi primary|fallback <tpl>` still works

### Watermark Optimization
- **200MB limit for all users** — watermark skipped for files > 200MB (was 500MB for free, 200MB for premium)

### Updated Commands
- **`/reloadconfig`** — now rebuilds load balancer from persisted endpoints

---

## v3.3 — Modern Broadcast (2026-09-21)

### Broadcast Center
- **Button-based menu** — `/broadcast` opens interactive broadcast center
- **📝 Text** — type message, preview, confirm, send
- **📷 Media** — send photo/video, optionally add caption, preview, confirm
- **🎭 Sticker** — send sticker, preview, confirm
- **↩️ Forward** — reply to message, forward as-is (preserves format)
- **Preview step** — see type, caption, recipient count before sending
- **Edit before send** — go back to change content
- **Cancel at any stage** — clean state reset

### Progress & Reliability
- **Live progress bar** — sent/failed/remaining counter
- **FloodWait auto-resume** — waits and continues automatically
- **Skip owner** — doesn't broadcast to bot owner
- **Chunked sending** — 50 users per batch with 2s delay

### New Files
- **`commands/broadcast.py`** — state machine, menu, preview, send with progress

### Updated Files
- **`utils/flood.py`** — added `patient_send_file` for media broadcasts
- **`main.py`** — registered broadcast pack, updated admin panel button
- **`README.md`** — updated broadcast description, project structure
- **`CHANGELOG.md`** — this entry

---

## v3.2 — API Load Balancer (2026-09-15)

### Load Balancing
- **Health-Aware Round-Robin** — distributes requests across N API endpoints
- **Circuit Breaker** — auto-disables endpoints after 5 consecutive failures (120s cooldown)
- **Auto-recovery** — failing APIs automatically retried after cooldown expires
- **Config-driven** — `API_ENDPOINTS` list in config.py, add/remove APIs without code changes
- **Per-API stats** — success rate, avg latency, request count, circuit state

### New Files
- **`utils/loadbalancer.py`** — `APIEndpoint` class + `LoadBalancer` singleton

### Config Changes
- **`API_ENDPOINTS`** — new list format replaces old `TERABOX_API_TEMPLATE`/`TERABOX_FALLBACK_API_TEMPLATE`
- Legacy templates kept for backward compatibility

### Updated Commands
- **`/apihealth`** — now shows load balancer stats (per-API success rate, latency, circuit state) + live probe

---

## v3.1 — Extended Format Support (2026-09-15)

### Format Expansion
- **67 video extensions** — added `.ogg`, `.mxf`, `.yuv`, `.viv`, `.m4p` (broadcast/pro formats)
- **45 photo extensions** — added `.dib`, `.rle`, `.jxl`, `.jxr`, `.tga`, `.pcx`, `.exr`, `.psd`, `.xcf`, `.pnm`, `.ppm`, `.pgm`, `.pbm`, `.ktx`, `.pef`, `.mrw`, `.srf`, `.sr2`, `.dcr`, `.erf`
- **112 total formats** — up from 90 (24% increase)
- JPEG XL (`.jxl`) — modern high-efficiency format
- OpenEXR (`.exr`) — film/VFX industry standard
- Camera RAW — Pentax, Minolta, Sony, Kodak, Epson variants
- OpenGL textures (`.ktx`) — game development support

### Boot Notification Cleanup
- **Removed stats line** — Users/Premium/Admins/Storage no longer shown in online status
- Cleaner, less noisy startup message

### README Updates
- **Domain count fixed** — accurate 47 supported TeraBox domains (was "50+")
- **Extension counts updated** — 67 video, 45 photo

---

## v3.0 — Modular Rewrite (2026-09-12)

### Architecture
- **Modular file structure** — split 4600-line `main.py` into `commands/`, `utils/`, `handlers/` directories
- **16 command modules** — admin, analytics, backup, cancel, config editor, library, maintenance, media, mystats, redeem, referral, status, UX
- **6 utility modules** — errors, flood protection, jobs, log redaction, premium, tags
- **Error isolation** — per-file download failures no longer crash entire handler
- **Boot notification** — pro card with build ID, boot number, packs count, storage ID, maintenance status

### Download System
- **HTTP 500 retries** — 3 attempts per file with progressive delay
- **Fallback API retry** — primary fails → fallback automatically
- **Strict file completion verify** — `!=` instead of `<` for file size check
- **Upload 2-retry loop** — retry on upload failure
- **mp4-only watermark** — non-mp4 files skip watermark instead of failing
- **In-flight dedup** — prevents duplicate downloads for same link (`dl:inflight:{code}`)
- **Cache system** — auto-send cached files, stale entry purge
- **Searchable library** — auto-index uploads, `/search`, `/reindex`

### Progress & UI
- **Fixed stuck progress bars** — watermark/compress/videoinfo timeouts resolved
- **Upload bars labeled "Uploading"** — distinguishes from download progress
- **Flood-aware edit backoff** — 2s throttle per edit, account-wide backoff on FloodWait
- **`/cancel` with job registry** — FFmpeg kill-on-cancel, file cleanup, waiter notification on failure
- **Cancel button removal** — buttons clear on all terminal states (success, failure, cancel confirmation)
- **Media tool menus** — `/mp3` bitrate selector (128/192/256/320), `/compress` resolution selector (480/720/1080, no upscaling)

### Premium System
- **Tag format fix** — `(OWNER)` parentheses, auto-remove when premium expires
- **Premium expiry reminders** — hourly sweep, 3d/1d/expired notifications
- **`/addpremium` `/delpremium` `/renew`** — full premium lifecycle
- **`/masstag` `/untag`** — bulk tag management
- **Member-since tracking** — `member_since:{uid}` Redis key

### Admin Tools
- **`/finduser`** — lookup any user's status/premium/tag
- **`/ban` `/unban`** — ban/unban users
- **`/addpremium` `/delpremium` `/renew`** — manage premium
- **`/masstag` `/untag`** — bulk tag/untag users
- **`/gcheck`** — validate gift cards
- **`/apihealth`** — check API response times
- **`/errors`** — recent error log entries
- **`/configview` `/configset` `/configreset`** — runtime config editor
- **`/setapi` `/reloadconfig`** — rotate API templates live
- **`/reindex`** — rebuild file library index
- **`/refstats`** — referral statistics
- **Audit log** — tracks all admin actions

### Referral System (v2)
- **New link format** — `ref_NTM-{tg_id}` (simple, readable, uses Telegram ID)
- **Count on join** — referral credited immediately when someone joins via link (not on first download)
- **Modern UI** — progress bars, tier visualization, share/claim/stats buttons
- **Self-redeem** — "Claim Reward" button to manually claim tier rewards
- **Cumulative tiers** — 5→1d, 10→3d, 25→7d (one-time at each threshold)
- **Self-ref protection** — cannot refer yourself, each user attributed once

### Safety & Reliability
- **FloodWait protection** — global edit backoff, patient_forward, patient_reply, patient_send
- **API log redaction** — URLs/tokens stripped from logs (`utils/logx.py`)
- **Centralized error messages** — `utils/errors.py` for consistent user-facing text
- **FFmpeg kill-on-cancel** — stops running video processing when user cancels
- **File cleanup on cancel** — partial downloads removed
- **Boot-clear stale claims** — `dl:inflight:*` and `dl:wait:*` cleared on startup
- **Restart flood-safe** — `/restart` and `/force` use patient_reply

### Broadcast & UX
- **Reply-to-forward** — broadcast preserves format, buttons, media
- **FloodWait resume** — broadcast pauses and continues after cooldown
- **Self-skip** — broadcast skips sending to the bot itself
- **Redeem confirmations** — show full name, username, user ID for both typed and button paths
- **Gift card auto-redeem** — button in channel posts auto-redeems on click

### Bug Fixes
- **Legacy Markdown escaping** — stray backslashes in captions fixed
- **Watermark timeouts** — `veryfast` preset + 300s timeout, was 900s+
- **Progress bar stuck at 90-100%** — videoinfo/watermark timeouts resolved
- **Font.ttf removed from git** — auto-downloads from GitHub on first watermark
- **CRLF line endings** — consistent across all files

---

## v2.x — Original Monolith

- Single `main.py` with all handlers
- Basic TeraBox download
- Premium system with gift cards
- Admin panel
- Media tools (mp3, compress)
- Button-based UI
- 3 languages (English, Nepali, Hindi)

---

## v1.0 — Initial Release

- Basic TeraBox link download
- Telegram bot interface
- Redis storage
