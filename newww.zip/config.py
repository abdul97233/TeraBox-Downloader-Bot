# ================== TELEGRAM API CONFIG ==================
# Get these from https://my.telegram.org/apps
API_ID = 19282751
API_HASH = "4c12ba0b4839ae5a1fd729337d2fc2ef"

# Bot token from @BotFather
BOT_TOKEN = "7024128732:AAGnUrUpmcC2xvfipMxnY6w0WlKX5B1PrFc"


# ================== REDIS DATABASE CONFIG ==================

# Redis Host / Port / Password
HOST = "redis-15739.c239.us-east-1-2.ec2.cloud.redislabs.com"
PORT = 15739
PASSWORD = "VAPdotKmtkWgXybTTu31o07sTMbMO3hA"   # Set to None if Redis has no password

# ================== BOT SETTINGS ==================

# Private storage chat where files are uploaded
# Use your private channel / chat ID (must be integer)
PRIVATE_CHAT_ID = -1001313190597


# Folder where downloaded videos are stored on the VPS
DOWNLOAD_DIR = "downloads"


# ================== ADMIN & OWNER ==================

# Owner — only this user can run /update, /setstorage
OWNER_ID = 803003146

# Admin user IDs (MUST be integers)
ADMINS = [
    803003146,
]


# ================== FORCE JOIN CHANNELS & GROUPS ==================

# Users must join these before using the bot
# Use username (e.g. "@NTMpro") or chat ID (e.g. -1001234567890)
FORCE_CHANNELS = [
    "@NTMpro",
]

FORCE_GROUPS = [
    "@NTMchat",
]


# ================== TERA BOX API ==================

# API Endpoints — load-balanced across all entries
# Add more endpoints here. No code changes needed.
API_ENDPOINTS = [
    {
        "name": "saiyan-primary",
        "url": "https://saiyanteraboxapi.saiyanprojects.com/",
        "token": "saiyankey0011",
    },
    {
        "name": "saiyan-secondary",
        "url": "https://saiyanteraboxapi2.saiyanprojects.com/",
        "token": "saiyankey0011",
    },
]

# Legacy templates (kept for backward compatibility, not used by load balancer)
TERABOX_API_BASE = "https://saiyanteraboxapi.saiyanprojects.com/"
TERABOX_API_TOKEN = "saiyankey0011"
TERABOX_API_TEMPLATE = (
    f"{TERABOX_API_BASE}?authkey={TERABOX_API_TOKEN}&url={{url}}"
)
TERABOX_FALLBACK_API_BASE = "https://saiyanteraboxapi2.saiyanprojects.com/"
TERABOX_FALLBACK_API_TEMPLATE = (
    f"{TERABOX_FALLBACK_API_BASE}?authkey={TERABOX_API_TOKEN}&url={{url}}"
)

# Self-hosted Telegram Bot API server (replaces https://api.telegram.org)
# Enables high-speed uploads up to 2GB via the Bot HTTP API.
TG_API_BASE = "https://saiyantg.saiyanprojects.com"

# ================== UPDATE SETTINGS ==================

GITHUB_REPO = "https://github.com/abdul97233/TeraBox-Downloader-Bot"
